const MODEL = "gemini-2.5-flash";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "explainImage", title: "🔊 Explain this image", contexts: ["image"] });
  chrome.contextMenus.create({ id: "explainPage", title: "🔊 Explain this screen", contexts: ["page"] });
  chrome.runtime.openOptionsPage();
});

async function getSettings() {
  return await chrome.storage.sync.get({ apiKey: "", lang: "hi-IN" });
}

function speak(text, lang) {
  chrome.tts.stop();
  chrome.tts.speak(text, { lang, rate: 1.0 });
}

function bufferToBase64(buf) {
  let bin = "";
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin);
}

async function imageUrlToBase64(url) {
  if (url.startsWith("data:")) {
    const [meta, data] = url.split(",");
    return { mime: meta.match(/data:(.*?);/)[1], data };
  }
  const res = await fetch(url);
  const blob = await res.blob();
  return { mime: blob.type || "image/jpeg", data: bufferToBase64(await blob.arrayBuffer()) };
}

async function askGemini(apiKey, lang, mime, data, kind) {
  const language = lang === "hi-IN" ? "simple Hindi (Hinglish is fine)" : "simple English";
  const prompt =
    `You are helping a blind person. Describe this ${kind} in ${language}. ` +
    `If it is a chart or graph: mention title, axes, trends and key numbers. ` +
    `If it is a meme: explain the joke. If it is a web page: describe layout, main content and buttons. ` +
    `Be clear and concise, plain text only, no symbols or markdown.`;
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: mime, data } }] }]
      })
    }
  );
  const json = await res.json();
  if (!res.ok) throw new Error(json.error?.message || "API error");
  return json.candidates?.[0]?.content?.parts?.map(p => p.text).join(" ") || "Kuch samajh nahi aaya.";
}

async function run(kind, getImage) {
  const { apiKey, lang } = await getSettings();
  if (!apiKey) {
    speak("Pehle settings mein API key daaliye.", "hi-IN");
    chrome.runtime.openOptionsPage();
    return;
  }
  speak(lang === "hi-IN" ? "Ek second, dekh raha hoon." : "One moment, looking.", lang);
  try {
    const { mime, data } = await getImage();
    const text = await askGemini(apiKey, lang, mime, data, kind);
    speak(text, lang);
  } catch (e) {
    speak("Error aaya. " + e.message, "hi-IN");
  }
}

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "explainImage") {
    run("image", () => imageUrlToBase64(info.srcUrl));
  } else if (info.menuItemId === "explainPage") {
    run("web page screenshot", screenshot);
  }
});

async function screenshot() {
  const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: "jpeg", quality: 80 });
  return { mime: "image/jpeg", data: dataUrl.split(",")[1] };
}

chrome.commands.onCommand.addListener((cmd) => {
  if (cmd === "explain-screen") run("web page screenshot", screenshot);
  if (cmd === "stop-speaking") chrome.tts.stop();
});
