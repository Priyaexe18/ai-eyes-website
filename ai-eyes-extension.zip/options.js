chrome.storage.sync.get({ apiKey: "", lang: "hi-IN" }, (s) => {
  document.getElementById("key").value = s.apiKey;
  document.getElementById("lang").value = s.lang;
});
document.getElementById("save").onclick = () => {
  chrome.storage.sync.set({
    apiKey: document.getElementById("key").value.trim(),
    lang: document.getElementById("lang").value
  }, () => { document.getElementById("msg").textContent = "Saved ✅"; });
};
